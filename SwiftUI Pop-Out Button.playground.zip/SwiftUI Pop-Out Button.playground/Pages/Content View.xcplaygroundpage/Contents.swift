import PlaygroundSupport
import SwiftUI

//Top Rectangle:        #28B463    rgb(40, 180, 99)
//Bottom Rectangle:     #20904f    rgb(32, 144, 79)

struct ContentView: View {
    
    var body: some View {
        VStack{
            Spacer()
            HStack{
                Spacer()
                Button {
                    print("Button Tapped")
                } label: {
                    PopOutButton()
                }
                Spacer()
            }
            Spacer()
        }
    }
}

struct PopOutButton: View {
    var body: some View {
        ZStack{
            VStack{
                Text("How to Make Your SwiftUI")
                    .bold()
                    .foregroundColor(.white)
                Text(" Buttons Pop-Out Using")
                    .bold()
                    .foregroundColor(.white)
                Text("Your Own Custom Colors")
                    .bold()
                    .foregroundColor(.white)
            }
            .padding()
            .zIndex(2)
            
            Rectangle()
            .foregroundColor(.topRectangle)
            .cornerRadius(15.0)
            .padding(4)
            .blur(radius: 3)
            .zIndex(1)
            
            Rectangle()
            .foregroundColor(.bottomRectangle)
            .cornerRadius(15.0)
                .zIndex(0)
        }
    }
}

extension Color{
    static let topRectangle = Color(red: 40 / 255, green: 180 / 255, blue: 99 / 255)
    static let bottomRectangle = Color(red: 32 / 255, green: 144 / 255, blue: 79 / 255)
}

// Present the view controller in the Live View window
PlaygroundPage.current.setLiveView(ContentView())
